---
doc_id: KB-003-EN
title: User roles and what each can do
lang: en
pair: KB-003-AR
area: Permissions
updated_at: 2026-03-10
---

## The four roles

| Role     | View | Draft | Send | Approve | Manage users |
| -------- | ---- | ----- | ---- | ------- | ------------ |
| Viewer   | ✓    | –     | –    | –       | –            |
| Editor   | ✓    | ✓     | –    | –       | –            |
| Sender   | ✓    | ✓     | ✓    | –       | –            |
| Approver | ✓    | ✓     | ✓    | ✓       | –            |

Only an **entity administrator**, a separate assignment layered on top of any
of the four roles, can manage users.

## Common confusion

An Editor who drafts a correspondence cannot send it themselves — drafting and
sending are separate permissions, by design, so a second person reviews outgoing
correspondence before it leaves the entity. The draft appears in the assigned
Sender's or Approver's queue.

A user with no role assigned can sign in but sees an empty workspace with no
error message, which is frequently reported as "the system is broken" when it
is in fact "no role assigned yet."

## Changing a role

Only an entity administrator can change a role, from **Administration > Users**.
The change applies immediately — no re-login required — but any correspondence
already open in the user's browser keeps the permissions it had when opened
until the page is refreshed.

## Related

- KB-004 — delegation during leave
