---
doc_id: KB-006-EN
title: Sign-in failures
lang: en
pair: KB-006-AR
area: Login
updated_at: 2026-04-28
---

## Order of checks

**1. Wrong password.** OLE5 shows a generic `Invalid credentials` message for
both a wrong password and an unrecognised username, deliberately, so a failed
attempt does not confirm whether an account exists. After 5 consecutive
failures the account locks — see KB-007.

**2. Account not yet activated.** A newly created account requires activation
through the link sent by email before first sign-in. The link expires after 72
hours; requesting a new one from the sign-in page invalidates the previous one.

**3. Single sign-on mismatch.** Entities that use SSO require sign-in through
the entity's identity portal, not through OLE5's own form. Attempting the OLE5
form directly for an SSO-enabled entity shows `This account requires
organisation sign-in`, which is often mistaken for a wrong-password error
because the wording does not mention SSO explicitly.

**4. Clock skew on the device.** OLE5's session tokens are time-based. A device
clock more than five minutes off from actual time can cause sign-in to appear
to succeed and then immediately expire. Rare, but consistent across browsers
on the same device is the signature of this cause.

## What to send to support

The exact error text, whether the entity uses SSO, and the approximate sign-in
time. Do not send the password itself in any circumstances — it is never needed
to diagnose the failure.

## Related

- KB-007 — locked account and session expiry
