---
doc_id: KB-002-EN
title: Supported and rejected attachment file types
lang: en
pair: null
area: Attachments
updated_at: 2026-04-02
---

## Accepted

- Documents — `.pdf`, `.docx`, `.xlsx`, `.pptx`
- Images — `.jpg`, `.jpeg`, `.png`, `.tiff`
- Text/data — `.txt`, `.csv`, `.xml`

The check reads file content, not the extension. Renaming a file to `.pdf`
does not make it acceptable.

## Rejected

Archives (`.zip`, `.rar`, `.7z`) and executables (`.exe`, `.bat`, `.msi`) are
rejected with `File type not permitted for attachment`. Archives are rejected
because their contents cannot be scanned — this is the most common cause of a
rejected attachment, since users compress files to stay under the size limit
and the compression itself triggers the rejection. Attach files individually
instead.

Legacy Office formats (`.doc`, `.xls`, `.ppt`) are also rejected. Use **Save
As** in Office to produce the modern equivalent.

## Password-protected and signed files

A password-protected PDF uploads but is not indexed — only its file name is
searchable. A digitally signed PDF uploads with the signature preserved, but
OLE5 does not validate or display signature status.

## Related

- KB-001 — attachment size limits
