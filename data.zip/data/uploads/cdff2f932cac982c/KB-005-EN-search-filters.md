---
doc_id: KB-005-EN
title: Advanced search filters and date ranges
lang: en
pair: null
area: Search
updated_at: 2026-01-22
---

## Opening advanced search

The main search box does a text match against subject and body. **Advanced
search** (the funnel icon beside it) adds filters that can be combined.

## Available filters

- **Date range** — sent or received between two dates. Defaults to the
  entity's local time zone regardless of the user's own.
- **Status** — draft, pending approval, sent, received, closed.
- **Sender / recipient** — by name or department, not free text.
- **Has attachment** — yes/no, independent of file type.
- **Correspondence number** — exact match on the reference number.

## How filters combine

All filters combine with **AND**, never OR. Selecting two departments in the
sender filter returns correspondence from either — the OR applies only within
a single filter's own options — but adding a date range on top narrows to
results that also fall inside it. There is no way to express "department A OR
date range X" across two different filters.

## Date range behaviour worth knowing

A range is inclusive of both endpoints. Selecting the same start and end date
returns everything from that single day, not zero results — a common point of
confusion when a user is trying to find "just yesterday's" correspondence.

An empty result on a valid date range where correspondence is known to exist
almost always means the status filter is still set from a previous search;
status is not cleared automatically when a new date range is chosen.

## Related

- KB-006 — sign-in failures (for search results appearing empty due to session)
