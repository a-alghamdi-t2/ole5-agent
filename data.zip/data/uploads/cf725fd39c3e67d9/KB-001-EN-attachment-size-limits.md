---
doc_id: KB-001-EN
title: Attachment size limits in OLE5
lang: en
pair: KB-001-AR
area: Attachments
updated_at: 2026-05-14
---

## Limits

- **10 MB** per single attached file.
- **25 MB** total attachments per correspondence.
- **20 files** maximum per correspondence.

All three must be satisfied before sending. Limits are checked against the
stored file size, not the size shown by a scanner or camera app.

These limits apply entity-wide and cannot be changed for one user. An entity
administrator can request a change through their account manager; changes take
effect the following working day.

## What the user sees

Exceeding the per-file limit stops the upload before transfer, with
`Attachment exceeds the maximum allowed size` shown next to the file in red.

Exceeding the _total_ limit is different: each file uploads fine individually,
and the error only appears on **send**. This is why some users report "the file
uploaded but the correspondence would not send."

## Reducing file size

- Scan at 200 dpi black-and-white instead of 300 dpi colour — typically cuts a
  text PDF to under a third of its size with no loss of legibility.
- Split a long document into numbered parts.
- For files that cannot be reduced, upload to the entity's document library and
  attach the link instead. Recipient access is checked against the library, so
  this does not bypass permissions.

## Related

- KB-002 — supported and rejected file types
